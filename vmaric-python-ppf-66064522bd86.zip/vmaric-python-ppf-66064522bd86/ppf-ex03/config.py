processor       = "Intel i7"
processor_speed = 3.5
ram_memory      = 8
hd_size         = 2.5
os_included     = True

print("Computer configuration: ")
print("#########################")
print("Processor: ")
print(processor)
print("Processor speed: ")
print(processor_speed)
print("Ram memory: ")
print(ram_memory)
print("HD size: ")
print(hd_size)
print("Has OS included: ")
print(os_included)