products    = ["Phone","Tv","Computer"]
prices      = [155.95,180.35,199.99]
#Your code here