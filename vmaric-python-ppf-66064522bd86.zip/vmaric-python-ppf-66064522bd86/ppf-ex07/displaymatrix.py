width   = 20
height  = 10
points  = [[2,4],[1,5],[6,6],[3,2],[0,0]]

#Your code here
