products    = ["Phone","Tv","Computer"]
prices      = [155.95,180.35,199.99]
for i in range(len(products)):
    print(products[i],":",prices[i])