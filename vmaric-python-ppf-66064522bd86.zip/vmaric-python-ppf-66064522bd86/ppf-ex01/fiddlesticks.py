print("Your bidding master!")
