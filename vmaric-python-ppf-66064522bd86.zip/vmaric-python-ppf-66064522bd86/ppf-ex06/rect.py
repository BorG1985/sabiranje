w = 10
h = 5
#Your code here