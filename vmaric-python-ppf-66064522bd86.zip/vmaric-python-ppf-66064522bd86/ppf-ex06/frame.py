w = 30
h = 15
#Your code here