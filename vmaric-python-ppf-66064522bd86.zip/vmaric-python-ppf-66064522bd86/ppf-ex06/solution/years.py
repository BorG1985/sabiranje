startDate   = 2010
endDate     = 2016
print("********* Allowed years *********")
for i in range(startDate,endDate):
    print(i)
print("*********************************")