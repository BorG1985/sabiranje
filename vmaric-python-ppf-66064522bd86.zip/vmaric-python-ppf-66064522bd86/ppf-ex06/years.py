startDate   = 2010
endDate     = 2016
#Your code here