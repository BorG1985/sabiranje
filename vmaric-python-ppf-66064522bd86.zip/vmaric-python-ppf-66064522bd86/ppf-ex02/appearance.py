'''
Forsaken by his people, he strode into the wasteland. He traveled far to the north, until he came to the great canyons. There, he founded a small village, Arroyo, where he lived out the rest of his years. And so, for a generation since its founding, Arroyo has lived in peace, its canyons sheltering it from the outside world. It is home. Your home.
'"'
print("Set your appearance")
z = input("Male or "female" (male/female)?")
if z=="male":
    print("You choose male)"
else:
    print("You choose female')