userage = int(input('Your age? '))
if(userage>=13):
    print("Access allowed")