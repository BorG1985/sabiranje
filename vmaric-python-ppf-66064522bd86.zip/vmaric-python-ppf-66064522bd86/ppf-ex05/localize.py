lang = input('Enter language? ')
if(lang=="en"):
    print("Hello")
elif(lang=="sr"):
    print("Zdravo")
elif(lang=="de"):
    print("Hallo")
else:
    print("Unrecognized language") 