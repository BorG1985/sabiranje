grade = int(input('Grade? '))
if(grade==1):
    print("Poor grade")
elif(grade==2):
    print("Not so poor grade")
elif(grade==3):
    print("Average grade")
elif(grade==4):
    print("Good grade")
elif(grade==5):
    print("Excellent grade!")
else:
    print("Unknown grade")