tax = 0.2
price = float(input("Enter price: ")) 
print("Price with tax is ", price + price * tax)