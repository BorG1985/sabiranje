allowed_age     = 13
age             = int(input("Enter your age: "))
print("Allowed - ", (allowed_age <= age))