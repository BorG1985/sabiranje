tax = 0.2
#Your code here