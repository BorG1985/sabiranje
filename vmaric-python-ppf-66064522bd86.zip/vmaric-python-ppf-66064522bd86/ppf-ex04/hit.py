proj_x      = 0
wall_x      = 7
proj_spd    = 2
#Your code here