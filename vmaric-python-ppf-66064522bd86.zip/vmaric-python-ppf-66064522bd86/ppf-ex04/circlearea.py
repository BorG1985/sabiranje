PI = 3.14
r = float(input("Enter radius: "))
print("Circle area is ", r**2 * PI)